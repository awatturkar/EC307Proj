package ggkaw.caces.doby;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class AddHomeworkTime extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_homework_time);
    }

    public void LaunchHWAssignmentTask(View view) {
    }

    public void LaunchHWDoneTask(View view) {
    }
}
